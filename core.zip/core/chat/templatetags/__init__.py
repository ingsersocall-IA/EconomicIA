# Necesario para que Django detecte este directorio como paquete de templatetags

